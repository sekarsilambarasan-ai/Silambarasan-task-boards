const KEY="silambarasan-task-board-v1";
let tasks=loadTasks(), currentFilter="All", deferredInstall=null;
const $=id=>document.getElementById(id);
function loadTasks(){try{return JSON.parse(localStorage.getItem(KEY)||"[]")}catch{return []}}
function save(){localStorage.setItem(KEY,JSON.stringify(tasks));render()}
function toast(msg){const el=$("toast");el.textContent=msg;el.classList.add("show");setTimeout(()=>el.classList.remove("show"),2300)}
function dateLabel(){return new Intl.DateTimeFormat(undefined,{weekday:"long",day:"numeric",month:"long",year:"numeric"}).format(new Date())}
$("todayLabel").textContent=dateLabel();
$("taskForm").addEventListener("submit",e=>{
 e.preventDefault();const title=$("taskTitle").value.trim();if(!title)return;
 tasks.unshift({id:crypto.randomUUID?crypto.randomUUID():String(Date.now()),title,date:$("taskDate").value,time:$("taskTime").value,category:$("taskCategory").value,priority:$("taskPriority").value,notes:$("taskNotes").value.trim(),done:false,created:Date.now()});
 save();e.target.reset();$("taskTitle").focus();toast("Task added to your board");
});
function render(){
 $("totalCount").textContent=tasks.length;$("pendingCount").textContent=tasks.filter(t=>!t.done).length;$("doneCount").textContent=tasks.filter(t=>t.done).length;
 const visible=tasks.filter(t=>currentFilter==="All"||(currentFilter==="Pending"?!t.done:t.done));
 $("taskList").innerHTML="";$("emptyState").style.display=visible.length?"none":"block";
 visible.forEach(t=>{
  const card=document.createElement("article");card.className="task-card"+(t.done?" done":"");
  const check=document.createElement("button");check.className="check";check.textContent=t.done?"✓":"";check.setAttribute("aria-label",t.done?"Mark pending":"Complete task");check.onclick=()=>{t.done=!t.done;save()};
  const content=document.createElement("div");
  const title=document.createElement("div");title.className="task-title";title.textContent=t.title;content.append(title);
  const meta=document.createElement("div");meta.className="task-meta";
  const due=[t.date,t.time].filter(Boolean).join(" • ");
  meta.innerHTML=`<span class="pill">${escapeHtml(t.category)}</span><span class="pill ${t.priority}">${escapeHtml(t.priority)} priority</span>${due?`<br>${escapeHtml(due)}`:""}${t.notes?`<br>${escapeHtml(t.notes)}`:""}`;
  content.append(meta);
  const actions=document.createElement("div");actions.className="task-actions";
  const edit=document.createElement("button");edit.textContent="✎";edit.setAttribute("aria-label","Edit task");edit.onclick=()=>editTask(t.id);
  const del=document.createElement("button");del.textContent="×";del.setAttribute("aria-label","Delete task");del.onclick=()=>{if(confirm("Delete this task?")){tasks=tasks.filter(x=>x.id!==t.id);save();toast("Task deleted")}};
  actions.append(edit,del);card.append(check,content,actions);$("taskList").append(card);
 });
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function editTask(id){const t=tasks.find(x=>x.id===id);if(!t)return;const title=prompt("Task title:",t.title);if(title===null)return;if(!title.trim()){toast("Task title cannot be empty");return}t.title=title.trim();const notes=prompt("Notes (leave blank for none):",t.notes||"");if(notes!==null)t.notes=notes.trim();save();toast("Task updated")}
document.querySelectorAll(".filter").forEach(b=>b.addEventListener("click",()=>{currentFilter=b.dataset.filter;document.querySelectorAll(".filter").forEach(x=>x.classList.toggle("active",x===b));render()}));
$("notifyBtn").addEventListener("click",async()=>{if(!("Notification"in window)){toast("Notifications are not supported in this browser");return}const p=await Notification.requestPermission();toast(p==="granted"?"Notifications enabled where supported":"Notification permission not granted")});
$("exportBtn").addEventListener("click",()=>{const blob=new Blob([JSON.stringify({app:"Silambarasan Task Board",exportedAt:new Date().toISOString(),tasks},null,2)],{type:"application/json"});const url=URL.createObjectURL(blob);const a=document.createElement("a");a.href=url;a.download="silambarasan-task-board-backup.json";a.click();URL.revokeObjectURL(url);toast("Backup file prepared")});
window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();deferredInstall=e;$("installBtn").hidden=false});
$("installBtn").addEventListener("click",async()=>{if(!deferredInstall){toast("Use browser menu → Add to Home screen");return}deferredInstall.prompt();await deferredInstall.userChoice;deferredInstall=null;$("installBtn").hidden=true});
if("serviceWorker"in navigator && location.protocol.startsWith("http"))navigator.serviceWorker.register("./sw.js").catch(()=>{});
render();